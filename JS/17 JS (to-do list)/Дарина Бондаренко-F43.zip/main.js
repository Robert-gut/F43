//!1
const obj = {
  key1: true,
  key2: null,
  key3: undefined,
  key4: "name",
  key5:[],
  key6:{}
};
function objHas(type) {
  for (const key in obj) {
     if (type == null && obj[key] == null) {
      return true;
    }
    if( typeof obj[key] === type){
      return true;
    }
  }
  return false;
}
console.log('task1-->', objHas('undefined'));
//!2
function hasEmptyValues(){
  for (const key in obj) {
    const valueOfKey = obj[key];
    if(!valueOfKey){
      return true;
    }
    switch (valueOfKey.constructor.name) {
      case 'Object':
        if(Object.keys(valueOfKey).length == 0){
          return true
        }
        break;
      case 'Array':
      case 'String':
        if(valueOfKey.length == 0){
          return true
        }
        break;
    
      default:
        break;
    }
   }
   return false;
 }
console.log('task2 -->', hasEmptyValues());
//!3
const goods = [
  { name: "Laptop", price: 1200 },
  { name: "Smartphone", price: 800 },
  { name: "Headphones", price: 150 },
  { name: "Keyboard", price: 100 },
  { name: "Mouse", price: 50 },
];
function sortByPrice() {
  return goods.sort((a, b) => a.price - b.price);
}
console.log("task3-->", sortByPrice());
//!4
function allObjProperties(){
  for (const key in obj) {
    console.log( key,':', obj[key]);
  }
}
console.log('task4 -->')
allObjProperties()